# NEXT BOT — START HERE (Handoff 97%)

**Stamp:** STAMP · CoS · 2026-09-15 · 23:42 MDT · Utah · 97% · NonNuclear  
**Desktop site of truth:** `/Users/rizal/Documents/ЯBOT/`  
**GitHub tip:** `a00e7c7` on RIZALEON/PROJECTR  
**Living cover:** `manual/USER-MANUAL.pdf` (20 pages, R2L, last word **HANDOFF RULE**)

## Mission
Begin building the coordinated **iOS · macOS · Android** app from the locked macOS clay foundation (APP-TEMPLATE-0.1). Do **not** invent a new aesthetic.

## Read first
1. `manual/USER-MANUAL.pdf` — last two pages (p.19–20)
2. `manual/USER-MANUAL.md`
3. `templates/APP-TEMPLATE-0.1/` + APP-CONTRACT if present
4. `templates/official-templates/index.json`
5. `landing/` — Bolte ManualCover landing pack

## Sequence law
macOS clay is locked at 97%. Now build macOS + iOS + Android **together** from the same clay design system.

## HARDCODES
- USER-MANUAL always rides every pack; fold INTO it; last page handoff; last word HANDOFF RULE; pages west-opposite (R2L)
- Я KOMMAND 0 · RESPAWN
- NonNuclear; Decider-gated; seated mind only

See full manual last leaf for complete next-bot checklist.
