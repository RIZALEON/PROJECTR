# Full wrap (templates + assets ~93 MB)

Chat attachments cap ~25 MB, so this LEAN pack carries manuals + landing + scripts + next-bot.

**Full wrap download (GitHub):**  
https://github.com/RIZALEON/PROJECTR/raw/main/handoff/HANDOFF-97-FULL-WRAP.zip

Or clone `RIZALEON/PROJECTR` tip `a00e7c7`+ and open `handoff/`.
